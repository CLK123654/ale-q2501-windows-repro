import json
import os

from airflow import DAG, Dataset
from airflow.operators.empty import EmptyOperator
from airflow.utils.dag_parsing_context import get_parsing_context
import pendulum


with open(os.environ["TENANT_FACTORY_CONFIG"], encoding="utf-8") as handle:
    config = json.load(handle)

context = get_parsing_context()
for tenant in config["tenants"]:
    with DAG(
        dag_id=f"tenant_{tenant['tenant_id']}_daily",
        start_date=pendulum.parse(config["start_date"], tz=tenant["timezone"]),
        schedule=tenant["schedule"],
        catchup=False,
    ) as dag:
        previous = EmptyOperator(task_id="start")
        for task_id in sorted(tenant["stages"]):
            current = EmptyOperator(task_id=task_id)
            previous >> current
            previous = current
        finish = EmptyOperator(task_id="finish", outlets=[Dataset(tenant["dataset_uri"])])
        previous >> finish

globals()[dag.dag_id] = dag
