# 测站回传DAG发布材料

dags目录是候选DAG，solution目录包含可延期Sensor和Trigger。results目录保存事件处理账、测站回执、延期计划、序列化参数和DAG结构。release-summary.json供发布值班核对维护窗与测站结果。
