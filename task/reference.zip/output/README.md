# 租户日批DAG发布材料

dags目录包含候选DAG工厂及随包配置。release目录保存DAG清单、定向解析清单和维护窗安排。serialized目录是Airflow2.10.5生成的序列化结构，供编排平台导入前核对。
