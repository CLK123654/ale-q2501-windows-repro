from __future__ import annotations

import json
from pathlib import Path

import pendulum
from airflow import DAG, Dataset
from airflow.operators.empty import EmptyOperator
from airflow.utils.dag_parsing_context import get_parsing_context


CONFIG_PATH = Path(__file__).with_name("tenant_factory_config.json")


def load_config():
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def build_dag(spec, start_date, catchup):
    dag_id = f"tenant_{spec['tenant_id']}_daily"
    with DAG(
        dag_id=dag_id,
        start_date=pendulum.parse(start_date, tz=spec["timezone"]),
        schedule=spec["schedule"],
        catchup=catchup,
        default_args={"owner": spec["owner"]},
        tags=sorted(spec["tags"]),
    ) as dag:
        previous = EmptyOperator(task_id="start")
        for task_id in spec["stages"]:
            current = EmptyOperator(task_id=task_id)
            previous >> current
            previous = current
        finish = EmptyOperator(task_id="finish", outlets=[Dataset(spec["dataset_uri"])])
        previous >> finish
    return dag


config = load_config()
context = get_parsing_context()
for tenant in config["tenants"]:
    candidate_id = f"tenant_{tenant['tenant_id']}_daily"
    if context.dag_id is not None and context.dag_id != candidate_id:
        continue
    globals()[candidate_id] = build_dag(tenant, config["start_date"], config["catchup"])
