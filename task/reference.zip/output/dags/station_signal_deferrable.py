from __future__ import annotations

from airflow import DAG
from airflow.operators.empty import EmptyOperator
from pendulum import datetime

from solution.signal_sensor import DeferrableSignalSensor

STATIONS = [{'station_id': 'ridge-north', 'task_id': 'wait_ridge_north', 'after_cursor': 104, 'optional': False, 'timeout_seconds': 720}, {'station_id': 'river-intake', 'task_id': 'wait_river_intake', 'after_cursor': 68, 'optional': False, 'timeout_seconds': 720}, {'station_id': 'forest-west', 'task_id': 'wait_forest_west', 'after_cursor': 31, 'optional': True, 'timeout_seconds': 480}]

with DAG(
    dag_id='station_signal_deferrable',
    schedule=None,
    start_date=datetime(2026, 1, 1, tz="UTC"),
    catchup=False,
    max_active_runs=1,
    tags=["station-signal", "deferrable"],
) as dag:
    for station in STATIONS:
        wait = DeferrableSignalSensor(
            task_id=station["task_id"],
            event_file="{{ dag_run.conf['event_file'] }}",
            policy_file="{{ dag_run.conf['policy_file'] }}",
            station_id=station["station_id"],
            after_cursor=station["after_cursor"],
            optional=station["optional"],
            timeout_seconds=station["timeout_seconds"],
        )
        receipt = EmptyOperator(task_id=f"receipt_{station['station_id'].replace('-', '_')}")
        wait >> receipt
