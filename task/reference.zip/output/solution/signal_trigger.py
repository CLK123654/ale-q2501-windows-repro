from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import AsyncIterator

from airflow.triggers.base import BaseTrigger, TriggerEvent


def load_policy(path: str) -> tuple[set[str], set[str]]:
    policy = json.loads(Path(path).read_text(encoding="utf-8"))
    terminal = set(policy["terminal_statuses"])
    return terminal, terminal | {"PENDING"}


def scan_events(event_file: str, policy_file: str, station_id: str, after_cursor: int):
    terminal_statuses, allowed_statuses = load_policy(policy_file)
    rows = []
    for actual_line, text in enumerate(Path(event_file).read_text(encoding="utf-8").splitlines(), start=1):
        if not text.strip():
            continue
        row = json.loads(text)
        if row.get("source_line") != actual_line:
            raise ValueError(f"INVALID_SOURCE_LINE:{actual_line}")
        if (
            not isinstance(row.get("station_id"), str)
            or type(row.get("cursor")) is not int
            or row["cursor"] < 0
            or row.get("status") not in allowed_statuses
            or not isinstance(row.get("observed_at"), str)
            or not isinstance(row.get("detail"), str)
        ):
            raise ValueError(f"INVALID_EVENT_ROW:{actual_line}")
        rows.append(row)

    trace = []
    seen = set()
    active_cursor = after_cursor
    terminal = None
    for row in [item for item in rows if item["station_id"] == station_id]:
        key = (row["station_id"], row["cursor"], row["status"])
        if row["cursor"] <= after_cursor:
            decision = "STALE"
        elif key in seen:
            decision = "DUPLICATE"
        elif row["cursor"] < active_cursor:
            decision = "STALE"
        elif row["status"] in terminal_statuses:
            active_cursor = row["cursor"]
            decision = "EMIT"
            terminal = {
                "station_id": station_id,
                "cursor": row["cursor"],
                "status": row["status"],
                "observed_at": row["observed_at"],
                "detail": row["detail"],
            }
        else:
            active_cursor = row["cursor"]
            decision = "ADVANCE"
        seen.add(key)
        trace.append({
            "source_line": row["source_line"],
            "station_id": station_id,
            "event_cursor": row["cursor"],
            "status": row["status"],
            "decision": decision,
            "active_cursor": active_cursor,
        })
        if decision == "EMIT":
            break
    if terminal is None:
        raise RuntimeError(f"MISSING_TERMINAL:{station_id}")
    return terminal, trace


class CursorSignalTrigger(BaseTrigger):
    def __init__(self, event_file: str, policy_file: str, station_id: str, after_cursor: int):
        super().__init__()
        self.event_file = event_file
        self.policy_file = policy_file
        self.station_id = station_id
        self.after_cursor = after_cursor

    def serialize(self):
        return (
            "solution.signal_trigger.CursorSignalTrigger",
            {
                "event_file": self.event_file,
                "policy_file": self.policy_file,
                "station_id": self.station_id,
                "after_cursor": self.after_cursor,
            },
        )

    async def run(self) -> AsyncIterator[TriggerEvent]:
        terminal, _ = await asyncio.to_thread(
            scan_events,
            self.event_file,
            self.policy_file,
            self.station_id,
            self.after_cursor,
        )
        yield TriggerEvent(terminal)
