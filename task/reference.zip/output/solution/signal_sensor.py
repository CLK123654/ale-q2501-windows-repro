from __future__ import annotations

from datetime import timedelta

from airflow.exceptions import AirflowFailException, AirflowSkipException
from airflow.models.baseoperator import BaseOperator

from solution.signal_trigger import CursorSignalTrigger


class DeferrableSignalSensor(BaseOperator):
    template_fields = ("event_file", "policy_file")
    deferrable = True

    def __init__(self, *, event_file: str, policy_file: str, station_id: str, after_cursor: int, optional: bool, timeout_seconds: int, **kwargs):
        super().__init__(**kwargs)
        self.event_file = event_file
        self.policy_file = policy_file
        self.station_id = station_id
        self.after_cursor = after_cursor
        self.optional = optional
        self.timeout_seconds = timeout_seconds

    def execute(self, context):
        self.defer(
            trigger=CursorSignalTrigger(
                event_file=self.event_file,
                policy_file=self.policy_file,
                station_id=self.station_id,
                after_cursor=self.after_cursor,
            ),
            method_name="execute_complete",
            timeout=timedelta(seconds=self.timeout_seconds),
        )

    def execute_complete(self, context, event=None):
        if not isinstance(event, dict) or event.get("station_id") != self.station_id:
            raise AirflowFailException("TRIGGER_EVENT_CONTRACT")
        status = event.get("status")
        cursor = event.get("cursor")
        detail = event.get("detail")
        if type(cursor) is not int or cursor <= self.after_cursor or not isinstance(detail, str):
            raise AirflowFailException("TRIGGER_EVENT_CONTRACT")
        if status == "READY":
            return {"station_id": self.station_id, "cursor": cursor, "detail": detail}
        if status == "EXPIRED" and self.optional:
            raise AirflowSkipException(f"OPTIONAL_WINDOW_EXPIRED:{self.station_id}:cursor={cursor}")
        if status in {"REJECTED", "EXPIRED", "CANCELLED"}:
            raise AirflowFailException(f"{status}:{self.station_id}:cursor={cursor}")
        raise AirflowFailException("UNKNOWN_TRIGGER_STATUS")
